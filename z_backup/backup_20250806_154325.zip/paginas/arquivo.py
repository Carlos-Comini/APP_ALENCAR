
import streamlit as st
from pathlib import Path
from datetime import datetime
import mimetypes
import gspread
import re

# Caminho base: pasta 'arquivo' na raiz do projeto
BASE_DIR = Path(__file__).resolve().parent.parent / "arquivo"

# Lista de bancos conhecidos para identificar o nome mesmo que contenha outras palavras
BANCOS_CONHECIDOS = [
    "SICREDI", "SICOOB", "BRADESCO", "BANCO DO BRASIL", "CAIXA", "ITAU",
    "SANTANDER", "INTER", "NUBANK", "BTG", "C6", "XP"
]

def get_cnpjs_planilha():
    gc = gspread.service_account(filename=r'C:\Users\carlos.santos\Desktop\PROJETO_XML\credenciais.json')
    sh = gc.open_by_key('1bJOkcArR6DZK_7SYwiAiFZEPE9t8HQ1d6ZmDoigCPJw')
    ws = sh.worksheet('Empresas')
    cnpjs = ws.col_values(2)[1:]
    razoes = ws.col_values(3)[1:]
    return {cnpj: razao for cnpj, razao in zip(cnpjs, razoes)}

def extrair_info(nome_arquivo):
    nome_limpo = nome_arquivo.lower()
    cnpj_match = re.search(r"\d{14}", nome_limpo)
    data_match = re.search(r"(\d{2})_(\d{4})", nome_limpo)

    cnpj = cnpj_match.group() if cnpj_match else "geral"
    mes = data_match.group(1) if data_match else "00"
    ano = data_match.group(2) if data_match else "0000"

    banco = "desconhecido"
    for b in BANCOS_CONHECIDOS:
        if b.lower() in nome_limpo:
            banco = b.upper()
            break

    return cnpj, banco, ano, mes

def exibir():
    st.title("📁 Arquivos Contábil")

    BASE_DIR.mkdir(parents=True, exist_ok=True)
    st.subheader("📤 Enviar arquivos")

    tipos_aceitos = [
        "pdf", "jpg", "jpeg", "png",
        "xls", "xlsx",
        "doc", "docx",
        "ppt", "pptx",
        "txt"
    ]

    arquivos = st.file_uploader(
        "Envie arquivos (PDF, Excel, Word, Imagem, TXT...)", 
        type=tipos_aceitos, accept_multiple_files=True
    )

    if arquivos:
        for arq in arquivos:
            nome = arq.name
            cnpj, banco, ano, mes = extrair_info(nome)

            pasta_destino = BASE_DIR / cnpj / banco / ano / mes
            pasta_destino.mkdir(parents=True, exist_ok=True)

            caminho = pasta_destino / nome
            with open(caminho, "wb") as f:
                f.write(arq.read())

        st.success(f"{len(arquivos)} arquivo(s) enviado(s) com sucesso!")

    st.subheader("📂 Arquivos Armazenados")
    cnpjs_empresas = get_cnpjs_planilha()
    arquivos_listados = []

    for cnpj_dir in BASE_DIR.iterdir():
        if not cnpj_dir.is_dir():
            continue

        if st.session_state.get("usuario", {}).get("Tipo") == "Cliente":
            if cnpj_dir.name != st.session_state["usuario"]["Empresa_ID"]:
                continue

        razao_social = cnpjs_empresas.get(cnpj_dir.name, cnpj_dir.name)

        for banco_dir in cnpj_dir.iterdir():
            for ano_dir in banco_dir.iterdir():
                for mes_dir in ano_dir.iterdir():
                    for arquivo in mes_dir.iterdir():
                        tipo_mime, _ = mimetypes.guess_type(arquivo)
                        arquivos_listados.append({
                            "Empresa": razao_social,
                            "CNPJ": cnpj_dir.name,
                            "Banco": banco_dir.name,
                            "Ano": ano_dir.name,
                            "Mês": mes_dir.name,
                            "Nome": arquivo.name,
                            "Caminho": str(arquivo),
                            "Tipo": tipo_mime or "desconhecido"
                        })

    empresas = sorted(set(a["Empresa"] for a in arquivos_listados))
    filtro = st.selectbox("Filtrar por empresa", ["Todas"] + empresas)

    if filtro != "Todas":
        arquivos_listados = [a for a in arquivos_listados if a["Empresa"] == filtro]

    for arq in arquivos_listados:
        with st.expander(f'{arq["Nome"]} — {arq["Banco"]} {arq["Mês"]}/{arq["Ano"]} — {arq["Empresa"]}'):
            st.write(f"📌 Empresa: {arq["Empresa"]}")
            st.write(f"🏦 Banco: {arq["Banco"]}")
            st.write(f"📅 Data: {arq["Mês"]}/{arq["Ano"]}")
            with open(arq["Caminho"], "rb") as f:
                st.download_button("⬇️ Baixar", f, file_name=arq["Nome"])
