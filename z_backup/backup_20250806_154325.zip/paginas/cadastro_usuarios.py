import streamlit as st
from funcoes_compartilhadas.conversa_banco import salvar_usuario, conectar_google_sheets
from funcoes_compartilhadas.estilos import aplicar_estilo_padrao

def exibir():
    aplicar_estilo_padrao()
    st.header("Cadastro de Usuários")

    tipo = st.radio("Tipo de Usuário", ["Escritório", "Cliente"])
    with st.form("form_usuario"):
        nome = st.text_input("Nome")
        email = st.text_input("Email")
        senha = st.text_input("Senha", type="password")

        if tipo == "Escritório":
            permitir_cadastros = st.checkbox("Permitir Cadastros")
            permitir_ver_arquivo = st.checkbox("Permitir Ver Arquivo")
            permitir_ver_xml = st.checkbox("Permitir Ver XML")

            if st.form_submit_button("Salvar"):
                permissoes = {
                    "cadastrar": permitir_cadastros,
                    "ver_arquivo": permitir_ver_arquivo,
                    "ver_xml": permitir_ver_xml
                }
                salvar_usuario(nome, email, senha, "Escritorio", permissoes=permissoes)
                st.success("Usuário do escritório cadastrado.")

        else:
            planilha = conectar_google_sheets()
            empresas = planilha.worksheet("Empresas").col_values(2)[1:]
            empresa = st.selectbox("Empresa", empresas)
            permitir_ver_arquivo = st.checkbox("Permitir Ver Arquivo")
            permitir_ver_xml = st.checkbox("Permitir Ver XML")

            if st.form_submit_button("Salvar"):
                permissoes = {
                    "ver_arquivo": permitir_ver_arquivo,
                    "ver_xml": permitir_ver_xml
                }
                salvar_usuario(nome, email, senha, "Cliente", empresa=empresa, permissoes=permissoes)
                st.success("Usuário de cliente cadastrado.")
