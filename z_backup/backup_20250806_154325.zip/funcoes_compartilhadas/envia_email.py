def enviar_email(destinatario, assunto, mensagem):
    # Aqui você pode integrar SMTP, SendGrid, etc.
    pass
