import streamlit as st
import streamlit.components.v1 as components
from paginas import cadastro_empresas, cadastro_usuarios, arquivos_xml, dashboard, arquivo
from funcoes_compartilhadas.conversa_banco import autenticar_usuario
from funcoes_compartilhadas.estilos import aplicar_estilo_padrao

st.set_page_config(layout="wide", page_title="Gestão de XML")

# Estilo fullscreen real + sem sidebar
st.markdown(""" 
    <style>
        #MainMenu, header, footer {
            visibility: hidden;
        }
        .css-1d391kg, .css-fblp2m { display: none; }
        .block-container {
            padding: 1rem 2rem;
            max-width: 100%;
        }
        html, body, .stApp {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
    </style>
""", unsafe_allow_html=True)

# Inicializa variáveis de sessão
if "usuario_autenticado" not in st.session_state:
    st.session_state.usuario_autenticado = False
if "tipo_usuario" not in st.session_state:
    st.session_state.tipo_usuario = ""
if "dados_usuario" not in st.session_state:
    st.session_state.dados_usuario = {}

def exibir_login_html():
    with open("index_embutido_streamlit.html", "r", encoding="utf-8") as f:
        html = f.read()
    components.html(html, height=900, scrolling=False)

def processa_login_por_url():
    email = st.query_params.get("email")
    senha = st.query_params.get("senha")
    if email and senha:
        sucesso, tipo, dados = autenticar_usuario(email, senha)
        if sucesso:
            st.session_state.usuario_autenticado = True
            st.session_state.tipo_usuario = tipo
            st.session_state.dados_usuario = dados
            st.rerun()
        else:
            st.error("❌ Login inválido.")

if not st.session_state.usuario_autenticado:
    exibir_login_html()
    processa_login_por_url()
else:
    aplicar_estilo_padrao()

    # Menu horizontal
    menu = st.radio("Menu", [
        "Dashboard",
        "Empresas Clientes",
        "Usuários",
        "XMLs",
        "Arquivos",
        "Sair"
    ], horizontal=True)

    if menu == "Dashboard":
        dashboard.exibir()
    elif menu == "Empresas Clientes":
        cadastro_empresas.exibir()
    elif menu == "Usuários":
        cadastro_usuarios.exibir()
    elif menu == "XMLs":
        arquivos_xml.exibir()
    elif menu == "Arquivos":
        arquivo.exibir()
    elif menu == "Sair":
        st.session_state.usuario_autenticado = False
        st.session_state.tipo_usuario = ""
        st.session_state.dados_usuario = {}
        st.rerun()
